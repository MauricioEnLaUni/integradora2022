<div class="ofertaMain" id="oferta1">
    <div class="ofertaInd">
    <h3>
        Oferta Veraniega
    </h3>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque accumsan nisi diam, eget bibendum orci cursus sit amet. Aliquam mattis, elit quis semper congue, nisl enim placerat enim, eget volutpat magna massa sit amet risus. Proin libero aliquam.
    </p>
    <picture>
        <source 
                srcset="img\smol\oferta\saleOffersSmall.webp 767w,
                        img\salesOffer.jpg 768w"
                sizes="(max-width:767px) 767px,
                        768px"
                src="img\salesOffer.jpg"
                alt="Oferta veraniega"
        />
        <img src="img\salesOffer.jpg" alt="Oferta veraniega"/>
    </picture>
    </div>
    <div class="ofertaInd dNone">
    <picture>
        <source 
                srcset="img\smol\oferta\offerTagsSmall.webp 767w,
                        img\offersTag.jpg 768w"
                sizes="(max-width:767px) 767px,
                        768px"
                src="img\offersTag.jpg"
                alt="Oferta general"
        />
        <img src="img\offersTag.jpg" alt="Oferta general"/>
    </picture>
    </div>
</div>