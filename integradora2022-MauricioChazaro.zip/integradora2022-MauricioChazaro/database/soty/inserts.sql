-- INSERTS


-- INSERT ITEM
INSERT INTO ITEM VALUES(NULL,'overjoyed headrest',790.15,647.66,14,2,1,1,1,3,2,'2019-01-12');
INSERT INTO ITEM VALUES(NULL,'available implement',154.01,126.24,22,2,2,1,6,4,1,'2016-12-11');
INSERT INTO ITEM VALUES(NULL,'stormy cousin',2158.34,1769.13,19,2,1,1,7,4,1,'2013-06-30');
INSERT INTO ITEM VALUES(NULL,'fresh wide-eyed',1763.25,1445.29,25,4,4,2,1,6,4,'2017-07-07');
INSERT INTO ITEM VALUES(NULL,'pretty jaded',307.79,252.29,15,1,1,2,8,2,5,'2013-04-13');
INSERT INTO ITEM VALUES(NULL,'ambiguous burrow',2146.71,1759.6,5,2,4,4,6,2,4,'2015-12-11');
INSERT INTO ITEM VALUES(NULL,'red currant',1592.88,1305.64,39,1,4,3,2,6,2,'2022-04-01');
INSERT INTO ITEM VALUES(NULL,'enchanting feigned',2090.03,1713.14,18,1,2,1,4,3,2,'2015-02-21');
INSERT INTO ITEM VALUES(NULL,'magnificent feeling',1119.3,917.46,34,2,4,1,6,3,2,'2019-10-05');
INSERT INTO ITEM VALUES(NULL,'ethereal pilaf',430.53,352.89,21,1,3,4,3,5,1,'2010-04-21');
INSERT INTO ITEM VALUES(NULL,'accessible dinghy',2323.33,1904.37,10,3,4,1,6,3,2,'2012-03-05');
INSERT INTO ITEM VALUES(NULL,'salty sort',1786.21,1464.11,23,4,2,4,8,1,3,'2013-04-10');
INSERT INTO ITEM VALUES(NULL,'smoggy device',877.27,719.07,8,2,4,4,4,6,5,'2016-01-21');
INSERT INTO ITEM VALUES(NULL,'yummy dot',776.68,636.62,6,1,1,2,6,1,3,'2014-08-30');
INSERT INTO ITEM VALUES(NULL,'strange tadpole',1626.27,1333.01,34,3,1,2,6,5,4,'2019-10-10');
INSERT INTO ITEM VALUES(NULL,'lyrical placid',1576.33,1292.07,6,4,2,2,1,4,1,'2021-01-08');
INSERT INTO ITEM VALUES(NULL,'itchy formation',1306.32,1070.75,21,2,4,2,9,3,2,'2019-05-23');
INSERT INTO ITEM VALUES(NULL,'hushed adrenalin',1328.65,1089.06,35,1,3,1,8,3,1,'2020-05-12');
INSERT INTO ITEM VALUES(NULL,'magnificent dump',1433.61,1175.09,17,4,1,4,9,1,3,'2011-10-28');
INSERT INTO ITEM VALUES(NULL,'vengeful pickle',848.01,695.09,34,3,2,4,3,4,1,'2016-05-18');
INSERT INTO ITEM VALUES(NULL,'heartbreaking rambunctious',619.86,508.08,3,2,1,4,9,2,4,'2010-01-16');
INSERT INTO ITEM VALUES(NULL,'racial thinkable',1869.37,1532.27,37,4,2,2,10,2,3,'2019-03-01');
INSERT INTO ITEM VALUES(NULL,'kindhearted scarf',170.97,140.14,29,1,3,4,1,3,2,'2014-07-27');
INSERT INTO ITEM VALUES(NULL,'aware observatory',911.73,747.32,27,3,4,2,10,3,2,'2022-05-25');
INSERT INTO ITEM VALUES(NULL,'plain doc',2308.2,1891.97,14,1,4,3,1,5,1,'2021-09-03');
INSERT INTO ITEM VALUES(NULL,'frantic pathway',2042.52,1674.2,38,4,1,3,3,1,3,'2010-12-31');
INSERT INTO ITEM VALUES(NULL,'icy buffalo',1888.63,1548.06,37,1,2,1,5,5,6,'2016-06-15');
INSERT INTO ITEM VALUES(NULL,'spicy project',2379.39,1950.32,19,4,4,1,10,5,2,'2020-08-28');
INSERT INTO ITEM VALUES(NULL,'internal everything',2275.92,1865.51,17,1,3,2,8,3,4,'2018-01-29');
INSERT INTO ITEM VALUES(NULL,'fallacious psychotic',232.35,190.45,7,3,2,1,7,5,5,'2013-03-21');
INSERT INTO ITEM VALUES(NULL,'beautiful vogue',0.68,0.56,37,4,2,4,5,4,6,'2014-06-23');
INSERT INTO ITEM VALUES(NULL,'irate timbale',1684.51,1380.75,22,4,1,4,6,3,1,'2010-01-06');
INSERT INTO ITEM VALUES(NULL,'roasted prevention',1538.64,1261.18,5,4,4,3,3,6,2,'2010-06-06');
INSERT INTO ITEM VALUES(NULL,'lackadaisical odometer',1095.12,897.64,9,1,2,4,4,5,4,'2012-09-15');
INSERT INTO ITEM VALUES(NULL,'pretty exploration',1562.31,1280.58,7,4,4,3,2,3,5,'2017-06-24');
INSERT INTO ITEM VALUES(NULL,'tame shop',386.17,316.53,26,2,2,2,1,6,2,'2015-04-10');
INSERT INTO ITEM VALUES(NULL,'angry nickname',1028.09,842.7,23,2,4,4,3,1,3,'2013-03-27');
INSERT INTO ITEM VALUES(NULL,'unadvised coaster',1510.64,1238.23,18,2,1,2,3,4,5,'2014-08-27');
INSERT INTO ITEM VALUES(NULL,'tough fame',15.9,13.03,11,3,1,2,10,4,2,'2017-03-20');
INSERT INTO ITEM VALUES(NULL,'ethereal hat',173.74,142.41,5,1,1,2,5,5,1,'2015-12-31');
INSERT INTO ITEM VALUES(NULL,'gifted spectacles',66.87,54.81,30,3,2,1,1,2,4,'2020-04-30');
INSERT INTO ITEM VALUES(NULL,'abundant hyena',204.68,167.77,20,1,4,2,3,2,6,'2016-06-12');
INSERT INTO ITEM VALUES(NULL,'willing ceiling',140.42,115.1,2,3,3,2,3,4,3,'2018-08-09');
INSERT INTO ITEM VALUES(NULL,'juicy mode',164.2,134.59,21,3,2,2,5,2,5,'2014-10-31');
INSERT INTO ITEM VALUES(NULL,'shy boysenberry',1318.09,1080.4,23,3,1,3,8,5,2,'2018-12-27');
INSERT INTO ITEM VALUES(NULL,'legal pulley',109.76,89.97,32,2,2,1,2,5,1,'2017-02-02');
INSERT INTO ITEM VALUES(NULL,'ripe case',203.04,166.43,15,4,2,2,9,6,5,'2019-07-31');
INSERT INTO ITEM VALUES(NULL,'longing surfboard',1957.93,1604.86,16,2,1,2,1,2,2,'2014-02-13');
INSERT INTO ITEM VALUES(NULL,'giddy terror',41.94,34.38,1,2,4,2,7,3,4,'2019-08-31');
INSERT INTO ITEM VALUES(NULL,'roasted lyrics',1718.54,1408.64,35,3,4,2,2,1,1,'2010-07-19');
INSERT INTO ITEM VALUES(NULL,'dull lottery',487.59,399.66,11,2,4,4,1,4,2,'2012-05-15');
INSERT INTO ITEM VALUES(NULL,'shrill behold',101.31,83.04,1,2,4,3,7,4,5,'2020-06-11');
INSERT INTO ITEM VALUES(NULL,'friendly warden',1272.5,1043.03,8,4,3,3,10,3,4,'2015-09-18');
INSERT INTO ITEM VALUES(NULL,'craven feeding',2027.8,1662.13,7,2,1,3,5,4,1,'2019-01-06');
INSERT INTO ITEM VALUES(NULL,'squealing blueberry',1325.77,1086.7,28,1,1,4,8,3,4,'2018-11-07');
INSERT INTO ITEM VALUES(NULL,'glib pitching',1328.02,1088.54,14,4,3,3,4,6,1,'2017-05-25');
INSERT INTO ITEM VALUES(NULL,'absorbed alpha',806.02,660.67,34,2,1,4,6,2,6,'2013-05-24');
INSERT INTO ITEM VALUES(NULL,'cynical pansy',288.71,236.65,14,2,2,2,8,4,1,'2016-08-11');
INSERT INTO ITEM VALUES(NULL,'abiding determination',1925.44,1578.23,13,2,4,2,8,1,3,'2020-03-15');
INSERT INTO ITEM VALUES(NULL,'obeisant consulate',537.96,440.95,21,2,1,3,10,3,4,'2016-04-15');
INSERT INTO ITEM VALUES(NULL,'madly intensity',4.43,3.63,5,3,1,3,5,1,4,'2011-03-25');
INSERT INTO ITEM VALUES(NULL,'cowardly hospitable',64.59,52.94,39,1,4,2,4,5,4,'2018-04-20');
INSERT INTO ITEM VALUES(NULL,'debonair condition',243.15,199.3,5,4,4,3,4,1,4,'2019-07-03');
INSERT INTO ITEM VALUES(NULL,'ill inventory',588.83,482.65,34,1,1,2,6,3,6,'2020-08-02');
INSERT INTO ITEM VALUES(NULL,'direful tapioca',552.18,452.61,27,3,2,2,4,4,4,'2020-02-19');
INSERT INTO ITEM VALUES(NULL,'humorous scrap',588.14,482.08,5,3,2,2,1,2,2,'2013-09-01');
INSERT INTO ITEM VALUES(NULL,'acoustic processor',1528.75,1253.07,14,4,3,4,2,6,5,'2017-01-26');
INSERT INTO ITEM VALUES(NULL,'long coin',1995.75,1635.86,7,1,2,1,10,3,6,'2021-01-21');
INSERT INTO ITEM VALUES(NULL,'productive possibility',560.83,459.7,19,2,3,3,7,3,1,'2010-11-03');
INSERT INTO ITEM VALUES(NULL,'endurable calico',1318.0,1080.33,19,4,3,3,6,6,1,'2014-02-09');
INSERT INTO ITEM VALUES(NULL,'parched direful',1381.99,1132.78,14,1,2,2,6,5,5,'2010-10-18');
INSERT INTO ITEM VALUES(NULL,'literate hunger',493.6,404.59,36,2,1,2,3,5,4,'2011-06-05');
INSERT INTO ITEM VALUES(NULL,'finicky jewellery',256.68,210.39,4,2,3,1,7,3,1,'2021-03-26');
INSERT INTO ITEM VALUES(NULL,'half odometer',1873.49,1535.65,30,1,2,3,1,1,3,'2017-12-11');
INSERT INTO ITEM VALUES(NULL,'knowledgeable adventurous',1059.41,868.37,2,3,4,3,2,6,5,'2014-10-27');
INSERT INTO ITEM VALUES(NULL,'ethereal communist',2117.66,1735.79,12,3,2,3,2,4,5,'2019-12-25');
INSERT INTO ITEM VALUES(NULL,'quack lark',580.55,475.86,31,2,2,4,8,1,5,'2013-01-01');
INSERT INTO ITEM VALUES(NULL,'capable weak',550.22,451.0,8,4,3,4,1,3,2,'2016-06-13');
INSERT INTO ITEM VALUES(NULL,'discreet cation',2080.44,1705.28,27,2,2,3,6,5,4,'2018-12-08');
INSERT INTO ITEM VALUES(NULL,'illegal printing',1173.05,961.52,37,4,1,4,6,5,2,'2021-11-23');
INSERT INTO ITEM VALUES(NULL,'truculent knuckle',1766.06,1447.59,5,1,1,4,6,2,4,'2022-02-27');
INSERT INTO ITEM VALUES(NULL,'elated sight',988.31,810.09,4,3,1,2,10,5,5,'2011-03-10');
INSERT INTO ITEM VALUES(NULL,'faulty bacterium',817.5,670.08,35,4,4,2,7,6,6,'2020-11-07');
INSERT INTO ITEM VALUES(NULL,'combative minute',2130.35,1746.19,16,1,3,4,2,3,2,'2020-06-11');
INSERT INTO ITEM VALUES(NULL,'astonishing township',1806.99,1481.14,8,2,2,1,6,4,6,'2022-04-28');
INSERT INTO ITEM VALUES(NULL,'voracious path',193.82,158.87,22,2,1,1,5,6,4,'2012-10-25');
INSERT INTO ITEM VALUES(NULL,'open currant',1289.23,1056.75,24,1,1,4,4,1,4,'2018-06-21');
INSERT INTO ITEM VALUES(NULL,'decisive workable',1593.2,1305.9,30,1,4,1,5,4,1,'2014-02-24');
INSERT INTO ITEM VALUES(NULL,'wonderful youngster',1964.92,1610.59,38,3,2,4,9,2,3,'2012-04-16');
INSERT INTO ITEM VALUES(NULL,'staking interchange',217.64,178.39,38,3,2,1,6,4,3,'2021-04-23');
INSERT INTO ITEM VALUES(NULL,'gusty inverse',1245.6,1020.98,16,3,4,3,8,4,6,'2022-03-21');
INSERT INTO ITEM VALUES(NULL,'tasty chuck',1752.01,1436.07,6,1,2,2,7,6,4,'2016-12-23');
INSERT INTO ITEM VALUES(NULL,'afraid anesthesiologist',492.6,403.77,14,2,4,1,2,3,2,'2016-02-25');
INSERT INTO ITEM VALUES(NULL,'abashed debtor',1956.07,1603.34,25,4,3,3,1,6,4,'2011-03-07');
INSERT INTO ITEM VALUES(NULL,'weary utter',1219.6,999.67,37,2,4,3,6,4,6,'2010-10-06');
INSERT INTO ITEM VALUES(NULL,'red knot',1481.78,1214.57,9,3,1,2,6,2,6,'2020-08-21');
INSERT INTO ITEM VALUES(NULL,'zippy brushing',78.18,64.08,8,3,2,2,3,6,2,'2015-01-06');
INSERT INTO ITEM VALUES(NULL,'highfalutin uplift',2343.22,1920.67,20,1,2,1,4,5,1,'2015-05-30');
INSERT INTO ITEM VALUES(NULL,'mysterious shaggy',1289.53,1056.99,24,2,1,4,2,2,1,'2013-03-14');
INSERT INTO ITEM VALUES(NULL,'gullible victorious',1664.73,1364.53,3,2,1,2,6,5,2,'2013-07-17');


-- Insert ADDRESS
INSERT INTO ADDRESS VALUES(NULL,232,"enigma","709039","canvas","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,796,"tritone","295137","piglet","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1445,"corridor","83426","earring","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1037,"gas","97119","hug","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,693,"context","616088","need","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,225,"charity","171795","toaster","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,902,"familiar","721473","surgery","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1163,"nut","948773","ranch","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1354,"deal","616164","meatball","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1062,"vegetable","686918","sleet","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1342,"membrane","991167","autoimmunity","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,818,"parser","363","retention","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,964,"church","914157","refreshments","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,134,"loop","278340","hallway","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,738,"skiing","457913","rainbow","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,683,"hat","956417","people","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,643,"pinto","662146","hull","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1115,"suppression","315483","vagrant","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,992,"array","71169","colleague","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,823,"labourer","33379","barbecue","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,190,"adaptation","600345","mutation","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,362,"strawman","518328","agony","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,708,"canopy","917355","moccasins","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,583,"altitude","275377","cloakroom","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,713,"sunday","889484","bugle","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,454,"charger","546682","webpage","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,452,"heifer","573817","whirlpool","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,538,"place","132440","satellite","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,103,"will","635057","bathrobe","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,364,"bathhouse","477644","gambling","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,906,"deposit","111229","stepson","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,832,"sesame","439072","clipper","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,491,"baby","314329","basin","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,458,"pressurization","795316","hearsay","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,352,"salsa","463976","thanks","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,613,"relish","587920","apartment","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,591,"graph","392937","inlay","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1302,"moccasins","599748","boysenberry","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,677,"linguistics","403544","genre","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1075,"comportment","165329","baggy","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,480,"nerve","316499","fatigues","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1333,"apartment","319447","joy","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,706,"amendment","79840","dynamics","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,657,"statue","403472","weekender","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,853,"accountability","552516","shoat","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,898,"paintwork","248895","usage","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,823,"blow","351026","limit","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1301,"neuropsychiatry","847834","read","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1212,"impropriety","477032","diesel","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1457,"sanctity","349087","happiness","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,493,"family","631996","anybody","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,546,"tow-truck","975462","night","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,800,"hammock","14372","illness","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,536,"mesenchyme","403569","relative","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,986,"album","317923","authorisation","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1252,"stance","534691","hire","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1204,"thanks","314227","arrow","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,670,"resident","837295","flight","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,226,"whelp","584367","golf","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,431,"chronicle","586245","connotation","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,948,"proprietor","320517","production","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1103,"woodchuck","963574","banking","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1412,"coinsurance","239587","immigrant","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,833,"councilperson","772862","octet","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,687,"truck","660001","likeness","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,363,"orchard","800166","field","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1475,"tie","35270","picturesque","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,599,"wriggler","691958","jungle","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,183,"independence","914977","rule","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,940,"bongo","861904","boxspring","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1288,"chairperson","304324","chop","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,301,"sparerib","70215","shore","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1085,"scripture","700001","fortune","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,150,"travel","529262","puzzle","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,483,"progenitor","573753","mat","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,719,"twitter","757512","caramel","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1217,"hammer","446818","pound","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,495,"thaw","762746","jeans","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,124,"zebra","913521","impostor","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,154,"cartridge","70831","jackal","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,545,"rail","682704","salmon","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,562,"basil","791160","floor","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,711,"dill","635658","chronograph","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,447,"curtain","482375","dimension","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,770,"topic","850241","tin","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,960,"majority","59674","racing","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,637,"elderberry","745515","handsaw","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,318,"chicken","145008","confusion","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,567,"puppet","514547","alarm","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1236,"item","34191","pray","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,520,"nectar","49322","clarity","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1285,"saddle","838667","horde","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1290,"conga","476237","tortellini","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,706,"symbol","27764","cell","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,726,"ruin","352001","yoyo","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1474,"picnic","15013","logo","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1277,"bandana","885814","hobby","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1038,"ore","60242","fondue","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,149,"cascade","494533","loafer","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1269,"kitsch","838797","wiseguy","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1191,"sentence","853345","drummer","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1484,"mode","710175","sponsorship","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1414,"curio","817339","knock","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,516,"wilderness","323929","almond","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1055,"consulate","974200","exterior","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1287,"sheep","888952","crumb","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,488,"expertise","822561","oats","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,289,"postage","597632","echidna","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1376,"hydrocarbon","193865","hazelnut","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1290,"relief","516625","throat","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1452,"snowflake","618377","octet","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1110,"newsstand","38945","bafflement","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1275,"gene","528958","seeker","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1188,"sorbet","567168","cowboy","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1036,"prow","851356","placode","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,620,"financing","169927","thistle","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1222,"diner","588092","bitter","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1416,"domain","319293","testing","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,446,"jet","82067","fingerling","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,704,"yesterday","286539","chili","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,660,"alias","526086","disdain","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1445,"integrity","103748","octavo","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1448,"employment","113806","rudiment","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,953,"vignette","123560","inhabitant","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,711,"good","999807","push","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,508,"text","52528","siding","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,328,"procurement","825166","surplus","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,513,"tights","314417","impropriety","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,399,"crest","229785","crotch","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1382,"youth","652510","astronomy","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,538,"anchovy","496851","anteater","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,642,"screw","915240","warlord","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,750,"breadfruit","351893","anarchy","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,411,"corporation","807730","nondisclosure","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,941,"jack","244502","letter","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,835,"education","391226","ironclad","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,431,"death","246993","neck","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1365,"handmaiden","219257","cart","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,977,"daughter","460560","physics","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1138,"channel","955230","gelding","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1429,"synonym","478556","pansy","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1358,"detective","581356","encouragement","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,826,"cornflakes","436915","tenet","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,861,"doe","757725","propane","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,488,"funding","655320","servant","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,928,"cormorant","817581","meantime","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,989,"cooking","966839","wild","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,856,"hull","957117","calm","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,631,"mine","406314","ash","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1123,"cliff","881201","dilapidation","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1401,"tintype","84711","triad","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,810,"hundred","144135","infrastructure","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,490,"uncertainty","93669","crude","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,841,"remains","852444","honeydew","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1166,"mastoid","167525","survey","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,912,"corruption","413425","lemonade","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1095,"alpenglow","309574","beet","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,515,"grip","328849","catalysis","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,160,"hawk","769385","light","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,573,"havoc","761449","gel","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,852,"yellowjacket","311669","hydraulics","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,600,"solvency","996869","appreciation","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,930,"miracle","285816","figure","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,283,"defeat","520954","stot","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,781,"porcupine","44280","terrace","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1367,"locomotive","520510","statue","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,487,"interpretation","531684","tenant","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,905,"makeup","479652","interface","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,980,"personnel","612356","freezer","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,716,"argument","642483","gas","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,679,"macaroon","370494","stitcher","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1147,"gown","119127","pinstripe","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,144,"producer","782533","pub","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,146,"yourself","75387","wriggler","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1448,"vengeance","784534","employee","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1229,"value","267381","donut","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,1107,"creche","41571","regionalism","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,1475,"ride","474908","badge","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,960,"lookout","20664","barrel","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,438,"heirloom","262360","support","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1176,"wisdom","935431","nourishment","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,303,"estrogen","506953","measure","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,566,"imagination","203209","involvement","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1091,"mind","474077","bar","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,142,"tweezers","890732","light","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,588,"copying","434190","mosque","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,363,"arrangement","944923","ball","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1034,"bandolier","996753","honor","Ottawa","CA");
INSERT INTO ADDRESS VALUES(NULL,976,"beach","184885","father","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,184,"kidney","460477","lung","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,1106,"scrip","928472","pate","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1012,"red","623945","herb","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1156,"surplus","267946","trove","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,257,"nose","309637","suspenders","Aguascalientes","MX");
INSERT INTO ADDRESS VALUES(NULL,262,"subscription","202098","strike","Cd. de Guatemala","GU");
INSERT INTO ADDRESS VALUES(NULL,625,"pint","412882","bill","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,1106,"cause","277460","galley","Belmopan","BE");
INSERT INTO ADDRESS VALUES(NULL,1044,"mine","467623","cabin","Houston","US");
INSERT INTO ADDRESS VALUES(NULL,266,"malnutrition","511725","opening","La Habana","CU");
INSERT INTO ADDRESS VALUES(NULL,1347,"underwriting","837010","yoga","Houston","US");


INSERT INTO MATERIAL(mt_nm) VALUES('PIEL'),
						   ('TEXTIL'),
						   ('SINTETICO'),
						   ('PIEL TRAT');
INSERT INTO COLOR(cl_nm) VALUES ('BLANCO'),
								('NEGRO'),
                                ('AZUL'),
                                ('VERDE'),
                                ('AMARILLO'),
                                ('NARANJA'),
                                ('ROJO'),
                                ('GRIS'),
                                ('CAFE'),
                                ('MORADO');
INSERT INTO TPE(tp_nm) VALUES ('NIÑO'),
							  ('NIÑA'),
							  ('INFANTIL'),
							  ('NEUTRO'),
							  ('HOMBRE'),
							  ('MUJER');
INSERT INTO PAY(py_nm) VALUES('CREDITO'),
							 ('CONTADO');
INSERT INTO BRAND VALUES(NULL,"Nike"),
						(NULL,"Adidas"),
                        (NULL,"Reebok"),
                        (NULL,"Puma"),
                        (NULL,"Air Jordan"),
                        (NULL,"Converse"),
                        (NULL,"Vans"),
                        (NULL,"New Balance"),
                        (NULL,"Asics"),
                        (NULL,"Crocs"),
                        (NULL,"Kenneth Cole"),
                        (NULL,"WHB Market"),
                        (NULL,"Ilbean"),
                        (NULL,"Sorel"),
                        (NULL,"Eddie Bauer"),
                        (NULL,"Skechers"),
                        (NULL,"Under Armour"),
                        (NULL,"J.Jill"),
                        (NULL,"The Walking Company"),
                        (NULL,"The North Face"),
                        (NULL,"Easy Spirit"),
                        (NULL,"Mens Wearhouse"),
                        (NULL,"Clarks"),
                        (NULL,"Sanuk"),
                        (NULL,"Avenue"),
                        (NULL,"Caterpillar"),
                        (NULL,"Red Wing"),
                        (NULL,"Hunter"),
                        (NULL,"Belstaff"),
                        (NULL,"Ugg"),
                        (NULL,"Wolverine"),
                        (NULL,"G.H. Bass & Co."),
                        (NULL,"Nine West"),
                        (NULL,"Timberland"),
                        (NULL,"Merrell"),
                        (NULL,"Red Dress Boutique"),
                        (NULL,"Jimmy Choo"),
                        (NULL,"Hotter"),
                        (NULL,"Tory Burch");
                 
-- INSERT INTO PROVIDER
INSERT INTO PROVIDER VALUES(NULL,'outfielder','6765711463671750','6161191598','efficientadaptation3732@hotmail.com','outfielder.com');
INSERT INTO PROVIDER VALUES(NULL,'bowl','4978350072471775','2265200744','spookyagree2249@hotmail.com','bowl.com');
INSERT INTO PROVIDER VALUES(NULL,'windage','7627995073578166','8201882062','giganticcurse9129@yahoo.com','windage.com');
INSERT INTO PROVIDER VALUES(NULL,'digging','2037404730775384','7867600017','vacuoussole4119@hotmail.com','digging.com');
INSERT INTO PROVIDER VALUES(NULL,'cot','1786723412137909','3789265771','coldoutlet182@yahoo.com','cot.com');
INSERT INTO PROVIDER VALUES(NULL,'patient','9953478844437435','3066480770','solidarchives3721@yahoo.com','patient.com');
INSERT INTO PROVIDER VALUES(NULL,'validity','5174481887754447','1102340921','didacticmarket5186@hotmail.com','validity.com');
INSERT INTO PROVIDER VALUES(NULL,'colony','1616709529011567','7441096478','statuesqueseep6893@yahoo.com','colony.com');
INSERT INTO PROVIDER VALUES(NULL,'blank','9764295818726472','2019286524','unsightlyquotation2464@gmail.com','blank.com');
INSERT INTO PROVIDER VALUES(NULL,'fetus','7231376459841759','1342403394','gainfulfetch4665@hotmail.com','fetus.com');
INSERT INTO PROVIDER VALUES(NULL,'operation','5124056959087111','9613449223','arrogantthyme8596@hotmail.com','operation.com');
INSERT INTO PROVIDER VALUES(NULL,'twitter','6202736939732275','6106943136','mercifulescape8527@hotmail.com','twitter.com');
INSERT INTO PROVIDER VALUES(NULL,'perch','3998570995377095','9938581511','daffylike9543@hotmail.com','perch.com');
INSERT INTO PROVIDER VALUES(NULL,'clipboard','7026249725124867','9070306073','minorwine9050@yahoo.com','clipboard.com');
INSERT INTO PROVIDER VALUES(NULL,'criteria','2477770377483637','1188574868','receptiveweather641@gmail.com','criteria.com');
INSERT INTO PROVIDER VALUES(NULL,'mustard','9887466403898514','5339018688','jumpyvessel1916@gmail.com','mustard.com');
INSERT INTO PROVIDER VALUES(NULL,'certification','5842784298788844','2679291165','tightperspective699@yahoo.com','certification.com');
INSERT INTO PROVIDER VALUES(NULL,'gong','1124207761049804','6820705152','talentedsecret1365@hotmail.com','gong.com');
INSERT INTO PROVIDER VALUES(NULL,'clockwork','9400476183768597','8874018533','testedpapaya8225@gmail.com','clockwork.com');
INSERT INTO PROVIDER VALUES(NULL,'list','8164138172200977','7829835429','snobbishtear1314@yahoo.com','list.com');
INSERT INTO PROVIDER VALUES(NULL,'clogs','4551538005802214','4953630067','vulgarimpudence5651@gmail.com','clogs.com');
INSERT INTO PROVIDER VALUES(NULL,'rent','5273767165230200','8358658558','cooingabolishment45@gmail.com','rent.com');
INSERT INTO PROVIDER VALUES(NULL,'tape','6401086295604688','2169162726','nondescripttonality483@hotmail.com','tape.com');
INSERT INTO PROVIDER VALUES(NULL,'raise','3935387691339373','8235745146','flowerytatami8250@gmail.com','raise.com');
INSERT INTO PROVIDER VALUES(NULL,'isogloss','1903119597615685','5099880104','didacticcomfort8582@hotmail.com','isogloss.com');
INSERT INTO PROVIDER VALUES(NULL,'entertainment','3631016409120671','1493727627','brightqualification470@hotmail.com','entertainment.com');
INSERT INTO PROVIDER VALUES(NULL,'measurement','7296624105937220','2008515168','godlyinfiltration2322@hotmail.com','measurement.com');
INSERT INTO PROVIDER VALUES(NULL,'c-clamp','5087291812507810','1334169183','flagrantorientation8736@gmail.com','c-clamp.com');
INSERT INTO PROVIDER VALUES(NULL,'few','4758248905150858','6745334686','majesticharald7020@yahoo.com','few.com');
INSERT INTO PROVIDER VALUES(NULL,'vaulting','6925383122678640','3901726522','cutehypothesis1199@gmail.com','vaulting.com');

-- INSERTS INTO USERS
INSERT INTO USERS VALUES('US00','Steven989','Steven','Fink','Ul7MxEDKMRNxvQlr2DksBWrvykoD0pqLcZLLateAPUx8Mo18e9RNNFWTunoehCg6','9144628240217395',1,'steven165@gmail.com');
INSERT INTO USERS VALUES('US01','Jody311','Jody','Lewellen','1yhU8IzUZKWXDp0yuegcsSXR23w2OX6C1tCl7Fi7zTNkeYlIeE7oBo29o7PLNq8B','2450034458468489',1,'jody169@gmail.com');
INSERT INTO USERS VALUES('US02','Carmen603','Carmen','Turney','wSowy3AnHjtEWrAtuJxDNAfYBmjsv0wrtFuVeHcbIUmyXEIUCEGrca6ofAtsiLay','9826002985004922',1,'carmen760@yahoo.com');
INSERT INTO USERS VALUES('US03','Eula820','Eula','Williams','0cKwWYrqfbntcv3JnMPLmhbxu1s88RHOzKpom4JFGOwocpng4qyHS0TXxvHUdn7I','7090976883675361',0,'eula77@yahoo.com');
INSERT INTO USERS VALUES('US04','Sharon180','Sharon','Fox','ugGivugTgdLNjiUhZIyESCJsy789GZ4Ej3aSiSU60vkxcfZuxXegapPIcuC27H8Z','1775419719423949',1,'sharon665@yahoo.com');
INSERT INTO USERS VALUES('US05','Cary793','Cary','Boyd','enMhJuZqxl0pQ2zytyniTCPtdMUFenpBLxb39H0suKIW1HAEryyPJXyStKDJkj2P','7727505604391214',1,'cary278@yahoo.com');
INSERT INTO USERS VALUES('US06','Alejandro105','Alejandro','Rook','8KEFvaSwFtQUlWhdCu9H3hykCM6zqdjN32QHExyGqDkg9etDo6mxBb8CCIsKKGkJ','2263509303024647',1,'alejandro355@yahoo.com');
INSERT INTO USERS VALUES('US07','Kenneth94','Kenneth','Mullen','Jwgibp2wxUSgYPDst4yDsAtgJYDrZklRjyUcFaPBClZ0WJPBQEDbVrriilWDtAX6','4682061331173180',0,'kenneth110@hotmail.com');
INSERT INTO USERS VALUES('US08','Ralph549','Ralph','Armstrong','xb2swmjpfM7u5YwOO7WX5clmNVGGGFTOhAhM1cxeYvjejFNu8AycMOMKVF6SMSzq','6357682195161049',1,'ralph9@gmail.com');
INSERT INTO USERS VALUES('US09','Maria346','Maria','Snow','MfRR8EAtaAbsnMqK25yi3drKWGpGeGYwOMOhMaWiJVxPkP8UnSSCO1lEShbbUBcn','1356888420068313',1,'maria602@gmail.com');
INSERT INTO USERS VALUES('US010','Steven136','Steven','Lynch','zCsGCKAk2BrtpW4Rqpbd9P6ZZH1rqPIuXdIuFpHBJkxxZBqbXYSBQvyWUSuAcrZ8','7759942085196430',0,'steven194@mansion.com');
INSERT INTO USERS VALUES('US011','Albert347','Albert','Duran','LogltzETAM5euKeHAwZYaUuPKYP4SW7H2TuzuTkDDQJsBHCEaYSn8Y3urQBgT4eC','2484415804310125',1,'albert558@hotmail.com');
INSERT INTO USERS VALUES('US012','Kent923','Kent','Kinsey','xxK4Me5Rvi5cG0B7ZZ0pyidn9M3AqPOl9tf1MYmdqbfK4HgRjdxRNxBdPO4nocNH','1831109602607002',0,'kent388@gmail.com');
INSERT INTO USERS VALUES('US013','John866','John','Southern','60bgC9PEK4k3PfM2LA8xTnDsVqbFK8T8YUJ7BFO6fyNvUJTiprFRuUxKW5XnQZb6','8985058215936934',0,'john229@sausage.com');
INSERT INTO USERS VALUES('US014','Sophie930','Sophie','Lajoie','dKhdWVX5L0dKqvqEe8qoaZ0U5WBzmezbcEMXEZsn1vxrQG2HBbrarFp6zngtzsuK','8752173947485970',1,'sophie334@venison.com');
INSERT INTO USERS VALUES('US015','Charles719','Charles','Jones','1z9s46uwAi1fRD2e6AQzwN3JckrBpUuDY2hK9zuBmXUi5lv5pPYvgZXckd3Jtzgh','4781740134011447',0,'charles697@yahoo.com');
INSERT INTO USERS VALUES('US016','Brad17','Brad','Meader','U3lPcm4Zr50pdXSvHi5Q3quRB24ZATHFlz2CV9ImuBbIwS675ulB0atG49sE5bgQ','3877122156013488',0,'brad91@hotmail.com');
INSERT INTO USERS VALUES('US017','Julio108','Julio','Parson','69zkhbGxEGsCgtCJD6oIYvTmIbOj3rLkHXzwSD6Tl7ndYb9SFugI5YRDkRRuG04F','4811400641159222',1,'julio803@email.com');
INSERT INTO USERS VALUES('US018','Terrence560','Terrence','Bogdan','78jDWPtlAJ8qVvsTNR1L5DhVk8BydMLDDoUEBU8WDARjNIeskGzFOUajJ5Xx4dZS','3369166487884349',0,'terrence214@hotmail.com');
INSERT INTO USERS VALUES('US019','David721','David','Dubay','xldgmZHIgvjPExm9Kw0LMslaTVbIPQKykfaOd8Fm5Ylxl6mPf2d4jhr90wB7qIAj','2434574924308895',1,'david329@gmail.com');
INSERT INTO USERS VALUES('US020','Charity151','Charity','Majeski','BWe5lEp0pipnsGrZ2ljvZImyVfORSBC3m5fl1sCK2r5jcVCuln7dJoVxzXu4eGs7','8762107212427305',1,'charity49@gmail.com');
INSERT INTO USERS VALUES('US021','Timothy419','Timothy','Morris','06jfus5bbWduu83bcCXmRhgUGR0UbLKFZ8PxsC8KrABkE60oZ4OJpdeFdVjIRJx9','3702494140088749',0,'timothy841@yahoo.com');
INSERT INTO USERS VALUES('US022','Sarah619','Sarah','Vega','N2IIsMg1pc4PnFRADmnEgYwS8Y4QQ8xVAbsijHosDGTDTUk2mG5OOSFRZXNyuXxg','8141266248138563',0,'sarah936@hotmail.com');
INSERT INTO USERS VALUES('US023','Rose202','Rose','Esperon','EUcgD3YUUGzplGZQsglAvrhoyiIHhn5uyoqejNfjm75hW9NXJRJjFbyd5rq0xO1d','9022497619744037',1,'rose813@gmail.com');
INSERT INTO USERS VALUES('US024','Leo270','Leo','Hickey','pUsPCXWY69lLHK8rVJGz3QKXW78xQeLzCg6BTigP8FoDMxypKPpnsleYNJutC7ar','6215639651211626',0,'leo193@gmail.com');
INSERT INTO USERS VALUES('US025','Zack9','Zack','Ellis','KcZPc4QYCRoOYk6OilQYZ2wp3NMaGQrv6fiOt1SJVxtY2iKsEn79x34sG4SrsNfL','2227710030454618',1,'zack859@gmail.com');
INSERT INTO USERS VALUES('US026','Hsiu238','Hsiu','Flemings','cSAU6oXXaIz9KG7KJ2kfBdOVWSiN9lrdV4qV6el7j8qsSYNUP2vG7ZBqXPzhs2wf','5793158943151015',1,'hsiu283@yahoo.com');
INSERT INTO USERS VALUES('US027','Laura39','Laura','Mcray','2kZHXI3IS5snpZkbLyDLTSmJoyHYGw5lmSI0Pp9KA9hGvwg4FgoHCYNTWPLlx69A','2518899517193077',0,'laura148@hotmail.com');
INSERT INTO USERS VALUES('US028','Joseph76','Joseph','Norman','wFbXnLpT4VAnMuU0v0inwemYPcnPsVz16otabZn7GUGgZ6VrUMs3CPWXm2hSPnba','1073201317226306',1,'joseph251@yahoo.com');
INSERT INTO USERS VALUES('US029','Bianca355','Bianca','Lawson','2WpHq94zOtHLbAqGoYtFYkDFwtuBTLpY1aL61DGo6qKAxZ1TJnokzrvgKKSDwgiL','1942915291515321',0,'bianca473@yahoo.com');
INSERT INTO USERS VALUES('US030','Mildred186','Mildred','Witt','QW3hXyLaS02jkK8JFN7ud7FyTp4e9RCyt5SD7n50uP81mJDizUbzf2G6ZNHUBDAr','8176390763220514',1,'mildred67@yahoo.com');
INSERT INTO USERS VALUES('US031','George159','George','Gonzales','4PCfuW9uL1qf7N5SBf4RLwGWYiRYWSLiTarMtsXL5jY5gEMGBWlPEmemN8x0owUk','8519742121993170',0,'george178@yahoo.com');
INSERT INTO USERS VALUES('US032','Earl334','Earl','Wright','uQOyZpr3dIdDEyQG9HylRWGd4cv198Y3TD1vAzLvL298I5fzPp2fUqwQr12fGwIb','5293817858029717',0,'earl795@hotmail.com');
INSERT INTO USERS VALUES('US033','John368','John','Hall','PyVynmbT5V3VOLFe33D47ntKsaC10d57EnFR6jG7Mjng04sWj1dm1XiYbMnrlJgr','7493374605069228',1,'john582@yahoo.com');
INSERT INTO USERS VALUES('US034','Ryan878','Ryan','Robertson','xGnIjxq23isq2of8qc4fNcYxTIoo2rRa9Kcira0tQ6fQgVO24n4hLUrQS7WRK7T5','3773172889969183',1,'ryan516@gmail.com');
INSERT INTO USERS VALUES('US035','Shirley311','Shirley','Burgess','GxFLy0AYFIRVrsvWDBhIGXMa7dR4Wv7H61S7dFncf2eC3MLTsoU6crOcClLoeTfP','3823107048822670',1,'shirley787@hurdler.com');
INSERT INTO USERS VALUES('US036','Kenneth954','Kenneth','Nelson','0gVV8qYI7L5i3l320P27IGjE5jQxNijXY9QEE2v33toljsgng2WjBTMAVh8sZfAW','4931263599168258',0,'kenneth412@gmail.com');
INSERT INTO USERS VALUES('US037','Miguel398','Miguel','Clarke','6z2yQyXHqGEzTDb9jf0YYPxW8NRr7CyXehTeV2Ae9GofBVURthX3RSkMnfcFBnUV','5849352550641617',1,'miguel925@gmail.com');
INSERT INTO USERS VALUES('US038','Connie830','Connie','Markle','zMBGXSUn8r82PbHqs5MYkOkSNUuwFC3e1Yq0OFSPJ3btvvox9j9c3hsi3AVxsTk5','5739488237357393',0,'connie772@gmail.com');
INSERT INTO USERS VALUES('US039','Christal167','Christal','Bailey','jx1fQP7EVPqwmZzXl12fh2rr30bumuaZmAzZODz9JhoxnrwYn6OeIlUwzfSDEYkH','7555503502078694',1,'christal324@gmail.com');
INSERT INTO USERS VALUES('US040','Joan823','Joan','Stockwell','NWiEGNq92Mi4k88zmpIHDd8A5vmjheoYAZ0khPseBfV3g3qIAsZaF1fAXnUX9JDv','4014882997370615',0,'joan645@fit.com');
INSERT INTO USERS VALUES('US041','Todd261','Todd','Lewin','GRN8FXcI7fUN99Yo2odtwvbaL1OUuIqX0UcB5MrdFzEBGj9hMLdwbABkIL5XzfDf','1585002547451075',0,'todd188@yahoo.com');
INSERT INTO USERS VALUES('US042','Eileen757','Eileen','Green','cXUY5byAlFto5hUD2uwvwBqgQgQADqKOSorlNG8pCSURy0RtPVhfAMK1hAeTDuru','8263895217120094',1,'eileen640@yahoo.com');
INSERT INTO USERS VALUES('US043','Mildred515','Mildred','Suitt','ZsPyRdR8pRK2AAVcsVFhnjRiHBm6S6FpLmdCDOV119VVxgUNFrNevIIF7uIptJVS','5476393370593312',1,'mildred751@hotmail.com');
INSERT INTO USERS VALUES('US044','Heidi216','Heidi','Love','lbrV662v0GuJsBwUfGJhkiovjhwZjFtjFEXENMVCSTV8PsHBeOSYggkW4DfKwz6C','1065012149863263',0,'heidi364@hotmail.com');
INSERT INTO USERS VALUES('US045','Robert618','Robert','Burks','q85EWYqjdjqyHUAhfdkSh869RYtRzoXPjPblXGbcz9Y759rOTyfqpbat3PH00XPX','7060663999507773',1,'robert495@yahoo.com');
INSERT INTO USERS VALUES('US046','Mark727','Mark','Aline','tFittUtCoj1V2X6eFohjYgDUnmJ36JDCEGsryvjA1UL15IdpBvwGgwELMD9BWUme','4665522564125896',0,'mark829@gmail.com');
INSERT INTO USERS VALUES('US047','Jolynn472','Jolynn','Kirkham','SL6LwCDHXzTIVHfxr9mnzmL9ra6KdZORScmCn1o4OWRxR9EZTlCvGYFNeZpTz8q3','4148240077600271',1,'jolynn255@gmail.com');
INSERT INTO USERS VALUES('US048','Cathleen399','Cathleen','Holloway','fR58ZiNm99p9Dtjq8xo21ut2eEghLo3j14JoLEf6ymhk239Vnbl7MV6AqauxJshU','8815352924513544',0,'cathleen70@inability.com');
INSERT INTO USERS VALUES('US049','Joshua358','Joshua','Scheer','YQJl618EGNuKXdlolA6XQfQTcoakeS0mSkSNtqRHGBEe4plNumJGLH68nP8kalUx','5349185467027388',0,'joshua979@hotmail.com');
INSERT INTO USERS VALUES('US050','Robt519','Robt','Slaughter','ixE7U3848rvmObmu9NR1fzyuKIP6h3EJ1StBXGDVs0icf7zznWhUwCez1bxm9fgT','3117135340163268',1,'robt68@yahoo.com');
INSERT INTO USERS VALUES('US051','Ramona634','Ramona','Lee','vYuNgmVQRvbEMf1FktjS5yRUP6V7hbHvobIa9FJZQnZWjbzViQNTsJ7uRaPY2lTG','8710860718204681',1,'ramona226@gmail.com');
INSERT INTO USERS VALUES('US052','Edna694','Edna','Crooms','DEHi0l619n6uzMNzDEMdoVRSMWrS6K6UJrJ1NzYog8gmqIgfdGSUAJPDoisPaAGc','2553249939420611',0,'edna61@gmail.com');
INSERT INTO USERS VALUES('US053','Charles705','Charles','Hall','4mhxyL0T9XQdl2R4vZGGPl3AoU1MHnpf10lqN7pc7A1P8j4An1wdA4l82VuROh2t','1838635293576950',1,'charles472@gmail.com');
INSERT INTO USERS VALUES('US054','Earl335','Earl','Lynch','vvyfv0mxsads6FdghSH1anW6BSddMDTpdZaAGoILx4ayG8qzmKTayTMaGkWgo7IP','6156700264047817',0,'earl888@yahoo.com');
INSERT INTO USERS VALUES('US055','Nancy206','Nancy','Phillips','SiVUgmrEmXQnJXw78PzoFvHdvateicUfl0qaXVfSF8dBCQrtMcUZ3eaT5x4AXMOo','6081836830245639',1,'nancy760@hotmail.com');
INSERT INTO USERS VALUES('US056','William857','William','Campos','LPqNP1eaCy63ApzOCpuEZDWIgTODj89b2r9LUHc9nzWomMTaoJmPY7BMcMRZM5YM','1270421630682789',1,'william774@gmail.com');
INSERT INTO USERS VALUES('US057','Virginia274','Virginia','Dean','2MTDFCUZ4YJKTdpRdL6ZHjf0y8PFcgJ1RsrTlIRBFRnfpfnsdd09OuAnxDFX4hEv','6489172664143565',0,'virginia107@gmail.com');
INSERT INTO USERS VALUES('US058','Jim56','Jim','Patterson','F0IsA7ciZwFaKs1gN0MwEOUZPNiPilR8mvIhTGQP3tAAp93H8YjufAcjTPvff3zM','7109388887093210',1,'jim708@gmail.com');
INSERT INTO USERS VALUES('US059','Tiffany152','Tiffany','Johnson','BzY34gkKaU1RjKfx6RhusiFpigAVx1DrGUwi6yWN2IxXfy9o9Iesn8PN3eJyFR16','6442721682852886',1,'tiffany562@gmail.com');
INSERT INTO USERS VALUES('US060','Sheila665','Sheila','Neblett','l3oLSuYmwgAVqygrUon3q0Hh0HWYND0BwG2jlgZ5Oh4fvkAkuktPMFk3XBQnHZdX','4685249642675478',0,'sheila926@yahoo.com');
INSERT INTO USERS VALUES('US061','Clara907','Clara','Reed','DfQOrX8ZxpM6LzwJQFngOg3ccIliG7Kk9dLOF2T06DCPtO3sgw0dftowv6t3n3TP','8677080572785964',0,'clara669@yahoo.com');
INSERT INTO USERS VALUES('US062','Hallie455','Hallie','Hinckley','fxRNT9RY3d4y63s8lMP0pgpiZ3oEQ34EsndgmmTtSFrxrKCHw9LxjJ0icYVth5KC','8795455775273466',1,'hallie113@hotmail.com');
INSERT INTO USERS VALUES('US063','Karen223','Karen','Evanoff','fK5UajaYQxWsKR1XlCxpfuGj5P0ZjbaZrUSoT6lwyfbArf9HOzcJdCnA6d7Y8jTm','3610513737763293',1,'karen398@yahoo.com');
INSERT INTO USERS VALUES('US064','Eric176','Eric','Reiter','bx2QVtqAfztL3sB7n5kZk0gh5CekHnyYcjXLbNCHY25YJVdEiK5hN1W87WhN5iv4','5461893787648136',0,'eric494@gmail.com');
INSERT INTO USERS VALUES('US065','Rosemarie616','Rosemarie','Schrader','3u5GHK1c9atm6FiB5AC46xtrvPLzYHEHbVakUBR1BdB6UuTjlpik5xnHnImcYN39','4402887091972483',0,'rosemarie945@variant.com');
INSERT INTO USERS VALUES('US066','Mildred667','Mildred','Cough','yZ5WN9Jw3k9iu1Ma8GUxKSyeuBZ0ww5kIuRlgv3n2wc8Uc38MF8VyIdmo2uQiJHQ','2584144486553587',1,'mildred436@yahoo.com');
INSERT INTO USERS VALUES('US067','Jose140','Jose','Crooks','hVKFKtpc4XTuRjiZJ6PgBsePoDi19iLgwG2LlY4y5Yxh2xeBY7BTQ1GLGciA6fIo','9264552935030504',0,'jose603@landing.com');
INSERT INTO USERS VALUES('US068','Reba7','Reba','Hayes','aSq94b9IXgrrpA6oKYRRIWnivPUlhbntDbQJQxBCYoOgghVb20fpXbbB5OibW76R','8826228247774022',1,'reba250@gmail.com');
INSERT INTO USERS VALUES('US069','Eleanor473','Eleanor','Hopper','Zjmn1DT9GqQboMz8FKqaGTtFgLmPOcaaJZPlGUzT3kzFVsq3n1ihHmpvMhC6YOIK','9697375226346140',0,'eleanor944@hotmail.com');
INSERT INTO USERS VALUES('US070','Angelica244','Angelica','Sallas','EQEUVqokF0gpFfi8zuHJ73p4fumDiP8kCBuVaCVmlAcJplJR6YMgod2PdLAwxXlp','2722309618020129',0,'angelica204@gmail.com');
INSERT INTO USERS VALUES('US071','Charles894','Charles','Watson','SNOIwVhOe4KxKYEZE5aKT1JtlLcz3Clb6hLgdRBXFfY7g8r9T3jQ5ICxGA7wdvrS','5758434827286090',1,'charles708@gmail.com');
INSERT INTO USERS VALUES('US072','Bree754','Bree','Huitink','qmQmHZiIwwr9sCVUFbFILuojQZsb4eLt1gaue0nsxba773c0kqtXyW4vEd5EISez','1076975902383359',1,'bree415@hotmail.com');
INSERT INTO USERS VALUES('US073','Manuela458','Manuela','Colon','I15EDc3IycxsDFiXlI0ZrFNBbPGN39Jyv8BOabiQKa62oayT8DXR0XeTqVxLter9','1756220074894496',0,'manuela389@gmail.com');
INSERT INTO USERS VALUES('US074','Wai697','Wai','Gonzalez','MceQi8vbACToWPFMEzcgAz5N06awCUF0XSVbCULrML59LLUBgFn43RLa2iafKZZK','7529342128687882',0,'wai279@gmail.com');
INSERT INTO USERS VALUES('US075','Dylan820','Dylan','Hodson','AQ2Xq530nS6JKnQIdBydZMnhLmJ9KuhlXMRJWXxCS8UuNDSlquZxtfr5nJO76VMt','1621750385895938',1,'dylan160@yahoo.com');
INSERT INTO USERS VALUES('US076','Kevin663','Kevin','Fahey','48SnbxUTj1opbBKjY6FzxF2RiY7WSS7ZDJdfJqzHMlMaLvUx6iO5ba2USri3tvrg','5776383304001332',1,'kevin866@hotmail.com');
INSERT INTO USERS VALUES('US077','Robert345','Robert','Rodriguez','eEt0EdskJCrDmiOQR8g9o9hoc4jceRl6vvfd2LCtryl7tPWN2XWDaXaEMtRvAGQD','9998536092536005',0,'robert126@gmail.com');
INSERT INTO USERS VALUES('US078','Evelyn338','Evelyn','Maxwell','OZ2eUAbJqYrRTjmOV2G7XJb8HfogcW8NPWhkQbXZQ8XbJcUzl1OJ6R51S6iPDcPT','4376876591881767',1,'evelyn641@gmail.com');
INSERT INTO USERS VALUES('US079','Shawn729','Shawn','Gruber','VvcmuPIVpxSAfSw1SdVqkXSJvv7B9rGaPJ47Bxve03w42Yf3N8miyLSw6fOLomsI','4842190907718682',1,'shawn667@gmail.com');
INSERT INTO USERS VALUES('US080','James229','James','Coddington','btIwyCI5euIxTmjS0TENzh4ayRLNdRZKCIifVsAEcR19ARAdMBEkqjBxgQQ9C7uz','4936847624540164',0,'james593@yahoo.com');
INSERT INTO USERS VALUES('US081','Maureen863','Maureen','Kline','LdZasQTPLYKglu1fijg9yXpjsNTJ2mbAShA7aIMRYdn3rtFlzjCkirjDrnirkk4B','8012629046709619',0,'maureen299@gmail.com');
INSERT INTO USERS VALUES('US082','Sandra611','Sandra','Shortell','f7WSfwCSLJIxX4c7RK5okYhn5ym2vkUYlLhsi8W8gBGae7BP4uPYsUMhtCYFdXwQ','7356100398500610',1,'sandra965@hotmail.com');
INSERT INTO USERS VALUES('US083','Barbara720','Barbara','Summers','R58lfDh9PNMUGVE5Jb9IPQMVaZKaV4GjF0iBQIBmxvNEZ36N1iVY3uf6Hr20KflE','5999063323264790',1,'barbara624@yahoo.com');
INSERT INTO USERS VALUES('US084','Alice956','Alice','White','pTJMAvCE3JZ8Tva2ErJR6VVeE5Q7yT0Uv2qM3IWKfiR58CUlulCpxYZ58pp2t52u','3268726848032555',1,'alice217@gmail.com');
INSERT INTO USERS VALUES('US085','Paul470','Paul','Widdows','lXlhzYtWzZVLGF9IdvY8vOyrWZSCBkV9rrfUgIIptWASKy3dodmlq491lob89dOu','2922705146203446',0,'paul206@yahoo.com');
INSERT INTO USERS VALUES('US086','Kathy493','Kathy','Smith','mgM3vjQc0QXWFW0XkzFo0BK9e1x95FkEcfJFxKUEl2p1U1NGMFdSPRVk3tmLwqXW','6781792518811452',1,'kathy120@yahoo.com');
INSERT INTO USERS VALUES('US087','Diane371','Diane','Thomas','IVQKwjOErTmafunY2QklxD2BkpsvsSpU9UgprdZ2zoepqSF4A9TMrLELIU4ppaVs','4048892456932719',1,'diane333@yahoo.com');
INSERT INTO USERS VALUES('US088','Leah641','Leah','Page','w76sgYggqzEQEktqW9aPhydjzCzwEfylXmBUTvN0OyOrkwEANSzWXhiOnTEL9vnK','2394135049305294',1,'leah458@yahoo.com');
INSERT INTO USERS VALUES('US089','Denise295','Denise','Flynn','KZziJZN6lJtV7fEnnumliM86tcGZWuDlDUB1Qi26rQtoAB71Mzg1FM1wgGh5aHQ0','5349922682931518',1,'denise679@hotmail.com');
INSERT INTO USERS VALUES('US090','Jose65','Jose','Brakefield','J8jFmbaKQbf9Erp1VnU0BMcQ2lNyQSxuEVK33LezU58OWj0erCAdm1B7XlCiNq6W','9123311635030948',0,'jose918@gmail.com');
INSERT INTO USERS VALUES('US091','Danny596','Danny','Cowett','eM9QeOkhQ4ocPZ8j3WrX3HeFokemPbekOQKJZfCIMubqytqwqEASRzZTR8udLu11','1607008948778735',1,'danny900@metric.com');
INSERT INTO USERS VALUES('US092','David342','David','Young','ZjYN4Gc1RYnoo4wPQIhODFnScA9OiSEFTbngyIGugnwpaOPWjFumegTfrz3SsMzy','2650951082954775',1,'david903@yahoo.com');
INSERT INTO USERS VALUES('US093','Trudy366','Trudy','Gravatt','WAqa9Mplue9lYs5oxw2xRBJMiO72OTmm1AyttIVTbseMaRrbkxRz9vBCUgfBqkgO','5701919835321707',1,'trudy14@gmail.com');
INSERT INTO USERS VALUES('US094','Carmen764','Carmen','Tolbert','wqty9HxlNdqB6VnXANHB9HkGpXW3Ny1zm9IYxmK1DbAvtyhaPCA3WGL6qqsMkDmM','4968633258046920',1,'carmen248@yahoo.com');
INSERT INTO USERS VALUES('US095','Velma898','Velma','Walton','f3JRKZkD6R5KzPldXgkb065WS2rzTXPzO0ThfR6ZH4vNKRyVP2E0hxPWeW1DazlQ','4340818292657316',0,'velma218@hotmail.com');
INSERT INTO USERS VALUES('US096','William972','William','Bascom','12EmbAoozglpfcpkO4RYCmbUPSzz19h78nE8FZ3rCYcv0H1lDBHJi1S35qgMwO6o','6678883163219968',1,'william717@cookie.com');
INSERT INTO USERS VALUES('US097','Cassandra898','Cassandra','Schultz','dY4Ux63qboFkiSX3ijx1FzXOOqiLdkl0rW8YNuaKd9Mm6YBacuQmedE7Px1HET59','5825805957410235',0,'cassandra119@communication.com');
INSERT INTO USERS VALUES('US098','Diane409','Diane','Johnson','wzMLamwy7PJ7RX3BDS3WoiZANv5zentSTh7V0Ir4NmL17lesLNa1q6uIbWQrUgac','2460456199049340',0,'diane62@yahoo.com');
INSERT INTO USERS VALUES('US099','Steven938','Steven','Wojcik','vNzgkUn6WN5gTP6ABEUSQ6Nso4Thfo6KRhpV37C14QfS6ehF9IJvuZI2fvcH4Cmo','4661258815651752',0,'steven948@spectrograph.com');
INSERT INTO USERS VALUES('US0100','Raymond812','Raymond','Rose','3SQQHiOiPMGrGjtwctJmSKv9FofhFhj1kFMzKa5oFJKO8IhTiFEY16gWEeMbMivP','9831619882029990',1,'raymond642@gmail.com');
INSERT INTO USERS VALUES('US0101','Karen325','Karen','Perkins','wKdXBKPrFK17zxeODxuMX4aTel7obSZ7WoyYrczSu4VBIUmtbU0ULFHfm0x5YRMe','1846377720877664',0,'karen469@bowtie.com');
INSERT INTO USERS VALUES('US0102','Elizabeth971','Elizabeth','Walls','6hDMal6ClCtpfiHphvST9tZJdSfcSuwNj2IvhglomlUWkO884lrl6i1r1ZEjjWyi','4307422108947819',0,'elizabeth172@gmail.com');
INSERT INTO USERS VALUES('US0103','Roy503','Roy','Hargett','OpoYVU0K4MuoWSfv3KOj3hg4yGYfCDzhUjIUfINeCRACzRQ69vuvkmFXIVPzaAnd','5202423444889100',1,'roy710@ramen.com');
INSERT INTO USERS VALUES('US0104','Tara806','Tara','Allen','CbDzPbAr4yRYBNu2KAtZtoNDXEd2OipFJT0f7EvDJDuBLVgifVTZEiS86rKD303z','3774504185881249',1,'tara4@gmail.com');
INSERT INTO USERS VALUES('US0105','Christopher130','Christopher','Richardson','JzjZvpzIQoqEDXOOtEFedCdT3sqhGoRrYWVBVXAnFGaebVw0dEUG3dFt4jkheIYv','1132240916575883',1,'christopher84@gmail.com');
INSERT INTO USERS VALUES('US0106','Elinore690','Elinore','Whitesell','WVLu5KeT6NEaFqY5QuBNV4lM18DKoynsjQG9IgDLAzVugADyHym5mTzBaBnzlYDP','9188876639013512',1,'elinore152@gmail.com');
INSERT INTO USERS VALUES('US0107','Joshua416','Joshua','King','Y72Zof33aHJVnFSZwph9dIc0hSrOZm6231iQv97RvKDQWEBXnXtB1eQKUau7GnvM','9102694944641803',0,'joshua106@yahoo.com');
INSERT INTO USERS VALUES('US0108','Daniel154','Daniel','Raymond','CN6CeKXQ8xTHICS9PjRNLpvcL8UvPLr8Y7w7FyZIon3wrEhOmPyIvE8DOu4SuJvv','4271525742069158',1,'daniel340@pseudoscience.com');
INSERT INTO USERS VALUES('US0109','Virginia976','Virginia','Larkin','4fGCum7RYXvY1xh0fO53JlR0F6ftBEofjJb4LjglNoWwgHZBhd1VeX0e8oaYFOpC','3908351555295037',0,'virginia170@gmail.com');
INSERT INTO USERS VALUES('US0110','Misty632','Misty','Asberry','uvxkP5ZRGtMO8lQOrQLXNaorHjC6xwpLyotreGZPDB4REx8hXW8J0DjRo7eDlY2B','2779630876838296',0,'misty97@gmail.com');
INSERT INTO USERS VALUES('US0111','Mary570','Mary','Pinsonnault','Oqz8gz9nGFlNENIU4y6mPPWRRV6eSRV3Xd4S4pS2H1cKw3gzGmViQ3pphCon9tU0','8663176342589749',1,'mary748@gmail.com');
INSERT INTO USERS VALUES('US0112','Carol898','Carol','Herald','Oz4sJrEd4IvaHeCbR37YqIBq0DQz7vZawKxmtxRQOy0WtmeHvRQBxvcM8oDLpXdU','7151516815391609',1,'carol345@hotmail.com');
INSERT INTO USERS VALUES('US0113','Janet705','Janet','Miga','1VvWlIBgRNCKvzwMCng1EJBZZFer44mHsAIRk333dA5PKJaYamh1gIEdYIhKOHVi','5792767748562120',1,'janet92@sentiment.com');
INSERT INTO USERS VALUES('US0114','Laura203','Laura','Brewer','fsZPtGJmnuIXQ92cZnUfCbAfEcVEJiSESJUsJZWzA6dxbAKhJGxcZsFZnLcFVSU2','7182012409725342',0,'laura933@disembodiment.com');
INSERT INTO USERS VALUES('US0115','Henry90','Henry','Yard','pV27bHzEjx325pkZyb1kQCRADTWta0sFdQOr52KUvbgcDsNZhmjyjGs8ALqIS4TB','2132584353150638',0,'henry587@gmail.com');
INSERT INTO USERS VALUES('US0116','Patrice8','Patrice','Sammartino','sS8TFJ8dVtmMjjHainvYkzAzYjLmnHgZXuOM4fyVuqavtLJtXjCtaIey8AaGslEC','5310455427960886',1,'patrice876@gmail.com');
INSERT INTO USERS VALUES('US0117','Charles140','Charles','Conrow','qhpLXAA8H07usIEePnjeXSF6Ldh0c5c0x6O75RmU5ZxDFvfMz3NeGM5Rt3Uv3Re1','6033996728917201',1,'charles250@hotmail.com');
INSERT INTO USERS VALUES('US0118','Richard331','Richard','Greiner','7M88MPqxdYyfLAafNgncKT8OwxKfraR4pNSFVcuBlaEKQIP5UW76Ieiq9pK5tENs','2197554400010213',1,'richard470@yahoo.com');
INSERT INTO USERS VALUES('US0119','Ronald2','Ronald','Hill','hQ54SQJVriO28jyHKCEyPVWgsluhuanfb5emJ9dSVYOUpXzEZgoLPT64v0z2cX8l','7616036298738937',1,'ronald680@yahoo.com');